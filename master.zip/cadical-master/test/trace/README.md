These are regression tests in form of API traces, which are read and
executed with the model based tester `mobical` in the build directory.

The `run.sh` script is only used for `make test`.

The `makefile` allows to run this tests with a single `make`.
